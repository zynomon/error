#ifndef TAN_H
#define TAN_H

#include <string>
#include <vector>
#include <mutex>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cerrno>
#include <limits.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef _WIN32
#include <windows.h>
#include <shellapi.h>
#include <direct.h>
#else
#include <unistd.h>
#include <sys/wait.h>
#include <pwd.h>
#include <fcntl.h>
#include <spawn.h>
extern char **environ;
#endif

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

class TAN {
private:
    inline static std::string terminalPath;
    inline static std::string configDir;
    inline static bool initialized = false;
    inline static bool safeModeEnabled = true;
    inline static std::vector<std::string> termArgs = {"-e"};
    inline static std::mutex stateMutex;
#ifndef _WIN32
    inline static std::vector<pid_t> children;
#endif

    static std::string trim(const std::string& s) {
        size_t b = s.find_first_not_of(" \t\r\n");
        if (b == std::string::npos) return "";
        size_t e = s.find_last_not_of(" \t\r\n");
        return s.substr(b, e - b + 1);
    }

    static std::string unquote(const std::string& s) {
        if (s.size() >= 2 && (s.front() == '"' || s.front() == '\'') && s.back() == s.front())
            return s.substr(1, s.size() - 2);
        return s;
    }

    static std::vector<std::string> splitArgs(const std::string& s) {
        std::vector<std::string> out;
        size_t i = 0;
        while (i < s.size()) {
            while (i < s.size() && (s[i] == ' ' || s[i] == '\t')) ++i;
            size_t start = i;
            while (i < s.size() && s[i] != ' ' && s[i] != '\t') ++i;
            if (i > start) out.push_back(s.substr(start, i - start));
        }
        return out;
    }

    static void makeDir(const std::string& path) {
#ifdef _WIN32
        _mkdir(path.c_str());
#else
        mkdir(path.c_str(), 0755);
#endif
    }

    static void ensureConfigDir() {
        if (!configDir.empty()) return;
        const char* home = NULL;
#ifdef _WIN32
        home = getenv("USERPROFILE");
        if (!home) home = getenv("HOME");
        if (!home) home = "C:\\";
#else
        home = getenv("HOME");
        if (!home || !*home) {
            struct passwd* pw = getpwuid(getuid());
            home = pw ? pw->pw_dir : NULL;
        }
        if (!home || !*home) home = "/tmp";
#endif
        std::string base = std::string(home) + "/.config";
        makeDir(base);
        configDir = base + "/error.os";
        makeDir(configDir);
    }

    static std::string getSyslinkPath() {
        ensureConfigDir();
        return configDir + "/tan";
    }

    static std::string getConfigPath() {
        ensureConfigDir();
        return configDir + "/tan.conf";
    }

    // tan.conf lives next to the "tan" syslink.
    static void loadConfig() {
        safeModeEnabled = true;
        termArgs = {"-e"};

        FILE* f = fopen(getConfigPath().c_str(), "r");
        if (!f) return;

        char line[1024];
        while (fgets(line, sizeof(line), f)) {
            std::string s = trim(line);
            if (s.empty() || s[0] == '#') continue;
            size_t eq = s.find('=');
            if (eq == std::string::npos) continue;

            std::string key = trim(s.substr(0, eq));
            std::string val = unquote(trim(s.substr(eq + 1)));

            if (key == "safemode") {
                safeModeEnabled = (val != "1");
            } else if (key == "tanargument") {
                std::vector<std::string> parsed = splitArgs(val);
                if (!parsed.empty()) termArgs = parsed;
            }
        }
        fclose(f);
    }

    static bool accessible(const std::string& path, bool needExec) {
#ifdef _WIN32
        (void)needExec;
        return GetFileAttributesA(path.c_str()) != INVALID_FILE_ATTRIBUTES;
#else
        return access(path.c_str(), needExec ? X_OK : F_OK) == 0;
#endif
    }

    static std::string findInPath(const std::string& name) {
#ifdef _WIN32
        char path[MAX_PATH];
        if (SearchPathA(NULL, name.c_str(), ".exe", MAX_PATH, path, NULL))
            return std::string(path);
        if (SearchPathA(NULL, name.c_str(), ".cmd", MAX_PATH, path, NULL))
            return std::string(path);
        if (SearchPathA(NULL, name.c_str(), ".bat", MAX_PATH, path, NULL))
            return std::string(path);
#else
        const char* pathEnv = getenv("PATH");
        if (!pathEnv) return "";
        std::string pathStr(pathEnv);
        size_t start = 0;
        while (start <= pathStr.size()) {
            size_t end = pathStr.find(':', start);
            std::string dir = (end == std::string::npos)
                                  ? pathStr.substr(start)
                                  : pathStr.substr(start, end - start);
            if (!dir.empty()) {
                std::string fullPath = dir + "/" + name;
                if (accessible(fullPath, true))
                    return fullPath;
            }
            if (end == std::string::npos) break;
            start = end + 1;
        }
#endif
        return "";
    }

    static std::string readSyslink(const std::string& syslink) {
#ifdef _WIN32
        std::string result;
        FILE* f = fopen(syslink.c_str(), "r");
        if (f) {
            char buffer[PATH_MAX];
            if (fgets(buffer, sizeof(buffer), f)) {
                buffer[strcspn(buffer, "\n")] = 0;
                result = buffer;
            }
            fclose(f);
        }
        return result;
#else
        char buffer[PATH_MAX];
        ssize_t len = readlink(syslink.c_str(), buffer, sizeof(buffer) - 1);
        if (len <= 0) return "";
        buffer[len] = '\0';
        return std::string(buffer);
#endif
    }

    static void writeSyslink(const std::string& syslink, const std::string& target) {
#ifdef _WIN32
        FILE* f = fopen(syslink.c_str(), "w");
        if (f) { fprintf(f, "%s", target.c_str()); fclose(f); }
        else fprintf(stderr, "TAN: could not cache terminal path to %s\n", syslink.c_str());
#else
        unlink(syslink.c_str());
        if (symlink(target.c_str(), syslink.c_str()) != 0)
            fprintf(stderr, "TAN: could not cache terminal path to %s: %s\n",
                    syslink.c_str(), strerror(errno));
#endif
    }

    // Order: $TERMINAL, the "tan" syslink (set by the installer), then a short built-in list.
    static std::string detectTerminal() {
        const char* envTerm = getenv("TERMINAL");
        if (envTerm && *envTerm) {
            std::string t = envTerm;
            if (t.find_first_of("/\\") == std::string::npos) t = findInPath(t);
            if (!t.empty() && accessible(t, true)) return t;
        }

        std::string syslink = getSyslinkPath();
        std::string cached = readSyslink(syslink);
        if (!cached.empty() && accessible(cached, true)) return cached;

#ifdef _WIN32
        const char* absolutePaths[] = {
            "C:\\Windows\\System32\\wt.exe",
            "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
            "C:\\Windows\\System32\\cmd.exe",
            NULL
        };
        const char* names[] = { "wt.exe", "powershell.exe", "cmd.exe", NULL };
#else
        const char* absolutePaths[] = {
            "/usr/bin/konsole",
            "/usr/bin/qterminal",
            NULL
        };
        const char* names[] = { "konsole", "qterminal", "xterm", NULL };
#endif
        for (int i = 0; absolutePaths[i]; i++) {
            if (accessible(absolutePaths[i], true)) {
                writeSyslink(syslink, absolutePaths[i]);
                return absolutePaths[i];
            }
        }
        for (int i = 0; names[i]; i++) {
            std::string path = findInPath(names[i]);
            if (!path.empty()) {
                writeSyslink(syslink, path);
                return path;
            }
        }

        fprintf(stderr, "TAN: no terminal found, symlink one to: %s\n", syslink.c_str());
        return "";
    }

#if defined(__APPLE__)
    static std::string escapeAppleScript(const std::string& s) {
        std::string out;
        for (size_t i = 0; i < s.size(); ++i) {
            char c = s[i];
            if (c == '\\' || c == '"') out += '\\';
            out += c;
        }
        return out;
    }
#endif

    static void init() {
        std::lock_guard<std::mutex> lock(stateMutex);
        if (initialized) return;

        loadConfig();

#if defined(__APPLE__)
        if (!accessible("/usr/bin/osascript", true)) {
            fprintf(stderr, "TAN: /usr/bin/osascript not found, cannot open Terminal\n");
            terminalPath = "";
        } else {
            terminalPath = "/usr/bin/osascript";
        }
#else
        terminalPath = detectTerminal();
#endif
        initialized = true;
    }

#ifndef _WIN32
    static std::string shq(const std::string& s) {
        std::string out = "'";
        for (size_t i = 0; i < s.size(); ++i) {
            if (s[i] == '\'') out += "'\\''";
            else out += s[i];
        }
        out += "'";
        return out;
    }

    static std::string shellBin() {
        return accessible("/bin/bash", true) ? "bash" : "sh";
    }

    static std::string wrapCommand(const std::string& cmd, bool asRoot, const std::string& exitFile) {
        std::string run = shellBin() + " -c " + shq(cmd);
        if (asRoot) run = "sudo " + run;

        std::string s;
        if (safeModeEnabled) {
            s += "printf '%s\\n' " + shq(asRoot ? "About to run as root:" : "About to run:") + "; ";
            s += "printf '  %s\\n' " + shq(cmd) + "; ";
            s += "printf 'Proceed? [y/N] '; read ans; ";
            s += "case \"$ans\" in y|Y|yes|YES) " + run + "; ec=$? ;; *) echo Aborted; ec=130 ;; esac; ";
        } else {
            s += run + "; ec=$?; ";
        }
        if (!exitFile.empty())
            s += "echo $ec > " + shq(exitFile) + "; ";
        s += "echo; printf 'Press Enter to close'; read _";
        return s;
    }

    static pid_t spawnRaw(const std::vector<std::string>& args) {
        if (args.empty()) return -1;

        std::vector<char*> argv;
        argv.reserve(args.size() + 1);
        for (size_t i = 0; i < args.size(); ++i)
            argv.push_back(const_cast<char*>(args[i].c_str()));
        argv.push_back(NULL);

        posix_spawn_file_actions_t actions;
        posix_spawn_file_actions_init(&actions);
        int devnull = open("/dev/null", O_RDWR | O_CLOEXEC);
        if (devnull >= 0)
            posix_spawn_file_actions_adddup2(&actions, devnull, STDIN_FILENO);

        pid_t pid;
        int rc = posix_spawn(&pid, argv[0], &actions, NULL, argv.data(), environ);

        if (devnull >= 0) close(devnull);
        posix_spawn_file_actions_destroy(&actions);

        if (rc != 0) {
            fprintf(stderr, "TAN: failed to launch '%s': %s\n", argv[0], strerror(rc));
            return -1;
        }
        return pid;
    }

    // Finished children are collected on the next call instead of touching the app's SIGCHLD handler.
    static void reapChildren() {
        for (size_t i = 0; i < children.size();) {
            int status = 0;
            pid_t r = waitpid(children[i], &status, WNOHANG);
            if (r == children[i] || (r < 0 && errno != EINTR))
                children.erase(children.begin() + i);
            else
                ++i;
        }
    }

    static bool spawnDetached(const std::vector<std::string>& args) {
        std::lock_guard<std::mutex> lock(stateMutex);
        reapChildren();
        pid_t pid = spawnRaw(args);
        if (pid <= 0) return false;
        children.push_back(pid);
        return true;
    }

    static std::vector<std::string> buildTerminalArgv(const std::string& innerCmd) {
        std::vector<std::string> argv;
#if defined(__APPLE__)
        argv.push_back(terminalPath);
        argv.push_back("-e");
        argv.push_back("tell application \"Terminal\" to do script \"" +
                       escapeAppleScript(innerCmd) + "\"");
#else
        std::string name = terminalPath.substr(terminalPath.find_last_of('/') + 1);
        argv.push_back(terminalPath);
        if (name == "konsole") argv.push_back("--nofork");
        for (size_t i = 0; i < termArgs.size(); ++i)
            argv.push_back(termArgs[i]);
        argv.push_back(shellBin());
        argv.push_back("-c");
        argv.push_back(innerCmd);
#endif
        return argv;
    }
#endif

public:
    static std::string term_bin_path() {
        init();
        return terminalPath;
    }

    static bool safemode_enabled() {
        init();
        return safeModeEnabled;
    }

    static bool tanrun(const std::string& cmd) {
        init();
        if (terminalPath.empty()) {
            fprintf(stderr, "TAN: tanrun failed, no terminal available\n");
            return false;
        }

#ifdef _WIN32
        std::string args = "/c \"" + cmd + " & pause\"";
        HINSTANCE r = ShellExecuteA(NULL, "open", terminalPath.c_str(),
                                    args.c_str(), NULL, SW_SHOWNORMAL);
        if (reinterpret_cast<INT_PTR>(r) <= 32) {
            fprintf(stderr, "TAN: ShellExecuteA failed (error %lu)\n", GetLastError());
            return false;
        }
        return true;
#else
        return spawnDetached(buildTerminalArgv(wrapCommand(cmd, false, "")));
#endif
    }

    static bool tanrunsu(const std::string& cmd) {
        init();
        if (terminalPath.empty()) {
            fprintf(stderr, "TAN: tanrunsu failed, no terminal available\n");
            return false;
        }

#ifdef _WIN32
        std::string args = "/c \"" + cmd + " & pause\"";
        SHELLEXECUTEINFOA sei = { sizeof(sei) };
        sei.fMask = SEE_MASK_NOCLOSEPROCESS;
        sei.lpVerb = "runas";
        sei.lpFile = "cmd.exe";
        std::string params = "/c " + terminalPath + " " + args;
        sei.lpParameters = params.c_str();
        sei.nShow = SW_SHOWNORMAL;
        if (!ShellExecuteExA(&sei)) {
            fprintf(stderr, "TAN: ShellExecuteExA failed (error %lu)\n", GetLastError());
            return false;
        }
        return true;
#else
        return spawnDetached(buildTerminalArgv(wrapCommand(cmd, true, "")));
#endif
    }

#if !defined(_WIN32) && !defined(__APPLE__)
    static bool tanrunWait(const std::string& cmd, int* exitCode = NULL) {
        init();
        if (terminalPath.empty()) {
            fprintf(stderr, "TAN: tanrunWait failed, no terminal available\n");
            return false;
        }

        char tmpl[] = "/tmp/tan_exit_XXXXXX";
        int fd = mkstemp(tmpl);
        if (fd < 0) {
            fprintf(stderr, "TAN: mkstemp failed: %s\n", strerror(errno));
            return false;
        }
        close(fd);
        std::string exitFile(tmpl);

        pid_t pid = spawnRaw(buildTerminalArgv(wrapCommand(cmd, false, exitFile)));
        bool ok = false;
        if (pid > 0) {
            int status = 0;
            pid_t r;
            while ((r = waitpid(pid, &status, 0)) < 0 && errno == EINTR) {}
            ok = (r == pid);
            if (!ok)
                fprintf(stderr, "TAN: waitpid failed: %s\n", strerror(errno));
        }

        if (ok && exitCode) {
            *exitCode = -1;
            FILE* f = fopen(exitFile.c_str(), "r");
            if (f) {
                int code;
                if (fscanf(f, "%d", &code) == 1) *exitCode = code;
                fclose(f);
            } else {
                fprintf(stderr, "TAN: could not read exit code from %s\n", exitFile.c_str());
            }
        }
        unlink(exitFile.c_str());
        return ok;
    }
#endif
};

#endif
