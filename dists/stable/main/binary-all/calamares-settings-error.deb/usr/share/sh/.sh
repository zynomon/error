
if [ "$vendor" = "GenuineIntel" ]; then
    echo "Removing AMD-specific drivers..."
    rm -rf /lib/modules/*/kernel/drivers/cpufreq/amd*
    rm -rf /lib/modules/*/kernel/drivers/platform/x86/amd*
    rm -rf /lib/modules/*/kernel/drivers/firmware/amd*
echo "amd drivers are removed"
elif [ "$vendor" = "AuthenticAMD" ]; then
    echo "Removing Intel-specific drivers..."
    rm -rf /lib/modules/*/kernel/drivers/cpufreq/intel*
    rm -rf /lib/modules/*/kernel/drivers/platform/x86/intel*
    rm -rf /lib/modules/*/kernel/drivers/firmware/intel*
fi
