import QtQuick 2.15
import calamares.slideshow 1.0

Presentation {
    id: presentation

    function nextSlide() {
        presentation.goToNextSlide();
    }

    Timer {
        id: advanceTimer
        interval: 7500
        running: true
        repeat: true
        onTriggered: nextSlide()
    }

    Slide {
        Image {
            source: "sil.png"
            anchors.fill: parent
            fillMode: Image.PreserveAspectFit
        }
    }

    Slide {
        Image {
            source: "neospace.png"
            anchors.fill: parent
            fillMode: Image.PreserveAspectFit
        }
    }

    Slide {
        Image {
            source: "scale.png"
            anchors.fill: parent
            fillMode: Image.PreserveAspectFit
        }
    }

    Slide {
        Image {
            source: "aware.png"
            anchors.fill: parent
            fillMode: Image.PreserveAspectFit
        }
    }

    Slide {
        Image {
            source: "drop.png"
            anchors.fill: parent
            fillMode: Image.PreserveAspectFit
        }
    }

    Slide {
        Item {
            anchors.fill: parent

            Image {
                source: "ins.png"
                anchors.fill: parent
                fillMode: Image.PreserveAspectFit
            }

            Text {
                font.family: "Monospace"
                font.pixelSize: 16
                color: "#FFFFFF"
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom
                anchors.bottomMargin: 20
                text: qsTr("Created by Zynomon aelius\n" +
                          "issues: https://github.com/zynomon/error \n" +
                          "email: zynomon@proton.me")
                wrapMode: Text.WordWrap
                width: parent.width - 40
                horizontalAlignment: Text.Center
            }
        }
    }
}